package com.fundacionneuron.proyectoneuronv34;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MiZona extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_zona);
    }
}